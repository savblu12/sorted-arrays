import UIKit

var str = "Hello, playground"

var shoecollection: [String] = ["Vapormaxes pros", "Airforces", "Kyries rainbow addition", "Jordan 12s"]




shoecollection.sort()
print(shoecollection)

